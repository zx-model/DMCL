import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import numpy as np
import pandas as pd
from torch.optim import Adam

# Helper function to convert a scipy.sparse.coo_matrix to a torch.sparse.FloatTensor
def coo_to_sparse_tensor(coo):
    values = coo.data
    indices = np.vstack((coo.row, coo.col))
    i = torch.LongTensor(indices)
    v = torch.FloatTensor(values)
    return torch.sparse.FloatTensor(i, v, torch.Size(coo.shape))

# Graph convolution layer definition
class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        return output + self.bias if self.bias is not None else output

class DMCLDataset(Dataset):
    """
    Dataset class to handle Beibei and Taobao data.
    """
    def __init__(self, dataset_name):
        # Assuming data files are in CSV format
        filename = f'{dataset_name.lower()}_data.csv'
        self.data = pd.read_csv(filename)
        self.users = torch.tensor(self.data['user_id'].values)
        self.items = torch.tensor(self.data['item_id'].values)
        self.behaviors = torch.tensor(self.data['behavior_type'].values)

    def __len__(self):
        return len(self.users)

    def __getitem__(self, idx):
        return self.users[idx], self.items[idx], self.behaviors[idx]

class GraphConvolution(nn.Module):
    """
    Graph Convolution Layer as used in GCN.
    """
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        return output + self.bias if self.bias is not None else output

class DMCL(nn.Module):
    """
    Dual-mode Augmented Contrastive Learning Model for recommendation systems.
    """
    def __init__(self, num_users, num_items, emb_dim, num_relations):
        super(DMCL, self).__init__()
        self.user_embedding = nn.Embedding(num_users, emb_dim)
        self.item_embedding = nn.Embedding(num_items, emb_dim)
        self.behavior_embeddings = nn.ModuleList([nn.Embedding(num_items, emb_dim) for _ in range(num_relations)])
        self.combination_encoder = GraphConvolution(emb_dim, emb_dim)
        self.cascade_encoder = nn.GRU(emb_dim, emb_dim, batch_first=True)

    def forward(self, user_ids, item_ids, behavior_types):
        user_embeds = self.user_embedding(user_ids)
        item_embeds = self.item_embedding(item_ids)
        behavior_embeds = torch.stack([self.behavior_embeddings[b](item_ids) for b in behavior_types]).mean(0)
        combined_features = F.relu(self.combination_encoder(behavior_embeds))
        _, cascade_features = self.cascade_encoder(combined_features.unsqueeze(0))
        final_features = combined_features + cascade_features.squeeze(0)
        return final_features

class ContrastiveLoss(nn.Module):
    """
    Contrastive Loss to enhance the discriminative power of embeddings.
    """
    def __init__(self, margin=1.0):
        super(ContrastiveLoss, self).__init__()
        self.margin = margin

    def forward(self, pos, neg):
        pos_dist = torch.sum(pos ** 2, dim=1)
        neg_dist = torch.sum(neg ** 2, dim=1)
        loss = torch.clamp(self.margin + pos_dist - neg_dist, min=0.0)
        return loss.mean()

def train(model, data_loader, loss_fn, optimizer):
    model.train()
    total_loss = 0.0
    for user_ids, item_ids, behavior_types in data_loader:
        optimizer.zero_grad()
        outputs = model(user_ids, item_ids, behavior_types)
        loss = loss_fn(outputs)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(data_loader)

num_users = 1000  # Adjust based on your dataset
num_items = 500   # Adjust based on your dataset
emb_dim = 64
num_relations = 3  # Adjust based on the types of behaviors in your dataset

model = DMCL(num_users, num_items, emb_dim, num_relations)
optimizer = Adam(model.parameters(), lr=0.001)
loss_fn = ContrastiveLoss(margin=1.0)

beibei_dataset = DMCLDataset('Beibei')
taobao_dataset = DMCLDataset('Taobao')
beibei_loader = DataLoader(beibei_dataset, batch_size=32, shuffle=True)
taobao_loader = DataLoader(taobao_dataset, batch_size=32, shuffle=True)

# Train on Beibei dataset
train_loss_beibei = train(model, beibei_loader, loss_fn, optimizer)
print(f'Training Loss on Beibei: {train_loss_beibei}')

# Train on Taobao dataset
train_loss_taobao = train(model, taobao_loader, loss_fn, optimizer)
print(f'Training Loss on Taobao: {train_loss_taobao}')



