import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="Run DMCL.")

    # Optimizer parameters
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate.')
    parser.add_argument('--lr_decay', action="store_true", help='Enable learning rate decay.')
    parser.add_argument('--lr_decay_step', type=int, default=10, help='Learning rate decay step.')
    parser.add_argument('--test_epoch', type=int, default=5, help='Test epoch steps.')
    parser.add_argument('--weights_path', default='', help='Path to store model weights.')
    parser.add_argument('--data_path', default='../Data/', help='Input data path.')
    parser.add_argument('--proj_path', default='', help='Project path.')

    # Dataset parameters
    parser.add_argument('--dataset', default='Beibei', choices=['Beibei', 'Taobao'],
                        help='Choose a dataset between Beibei and Taobao.')
    parser.add_argument('--verbose', type=int, default=1, help='Verbosity mode.')
    parser.add_argument('--is_norm', type=int, default=1, help='Enable feature normalization.')
    parser.add_argument('--epoch', type=int, default=500, help='Number of epochs.')

    # Model hyperparameters
    parser.add_argument('--embed_size', type=int, default=64, help='Embedding size.')
    parser.add_argument('--layer_size', default='[64,64]', help='Output sizes of each layer.')
    parser.add_argument('--batch_size', type=int, default=512, help='Batch size.')
    parser.add_argument('--regs', default='[1e-6,1e-5,1e-4,1e-3]', help='Regularizations.')
    parser.add_argument('--adj_type', default='pre', choices=['plain', 'norm', 'mean'],
                        help='Type of adjacency matrix.')
    parser.add_argument('--gpu_id', type=int, default=1, help='GPU ID.')

    # Dropout and regularization
    parser.add_argument('--node_dropout_flag', type=int, default=1, help='Activate node dropout.')
    parser.add_argument('--node_dropout', default='[0.5]', help='Node dropout ratio.')
    parser.add_argument('--Ks', default='[10, 50]', help='Top K ranks for evaluation.')
    parser.add_argument('--save_flag', type=int, default=0, help='Activate model saver.')
    parser.add_argument('--test_flag', default='part', choices=['part', 'full'], help='Test type for evaluation.')
    parser.add_argument('--report', type=int, default=0, help='Performance report flag.')

    # Augmentation and SSL specific parameters
    parser.add_argument('--aug_type', type=int, default=0, help='Augmentation type.')
    parser.add_argument('--ssl_ratio', type=float, default=0.5, help='SSL sample ratio.')
    parser.add_argument('--ssl_temp', type=float, default=0.5, help='SSL temperature.')
    parser.add_argument('--ssl_reg', type=float, default=1, help='SSL regularization weight.')
    parser.add_argument('--ssl_mode', type=str, default='both_side', choices=['both_side', 'single_side'],
                        help='SSL mode.')

    # Additional SSL settings
    parser.add_argument('--ssl_reg_inter', default='[1,1]', help='SSL regularization between interactions.')
    parser.add_argument('--ssl_inter_mode', type=str, default='both_side', choices=['both_side', 'single_side'],
                        help='SSL interaction mode.')

    # Further model specifics
    parser.add_argument('--n_fold', type=int, default=50, help='Number of folds for data partition.')
    parser.add_argument('--wid', default='[0.1,0.1,0.1]',
                        help='Weight decay settings for Beibei; adjust for Taobao if needed.')
    parser.add_argument('--decay', type=float, default=10, help='Regularization weight decay; adjust based on dataset.')
    parser.add_argument('--mf_decay', type=float, default=1, help='Decay factor for matrix factorization loss.')
    parser.add_argument('--coefficient', default='[1e-3,3e-3,1e-2,3e-2,1e-1,3e-1]',
                        help='Coefficients for regularization layers.')
    parser.add_argument('--mess_dropout', default='[0.3]', help='Message dropout rates.')
    parser.add_argument('--dropout_ratio', type=float, default=0.5, help='Overall dropout ratio.')

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    print(args)

